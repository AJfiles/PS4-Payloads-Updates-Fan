HERRAMIENTAS DE DIAGNÓSTICO (CARPETA DIAGNOSTIC)
Estos binarios NO son para uso diario. Son herramientas de validación:
write_verify_noop.bin:
Test de validación de primitivas de escritura
Escribe los valores actuales y los relee
No modifica estado de la consola
Uso: verificar que SetStr/SetInt funcionan antes de usar payloads v2
np_readonly_dual_probe.bin:
Sonda de solo lectura para diagnóstico
Lee claves de registro (NP_env, auto_download)
Reporta vía TCP al PC (puerto 9090)
Uso: verificar estado del sistema, compatibilidad en otros firmwares
Para usar la sonda:
En PC: python tools/receive_probe.py --port 9090
En consola: enviar np_readonly_dual_probe.bin vía BinLoader
Ver reporte en terminal del PC
Estas herramientas son seguras: solo leen, nunca escriben.
