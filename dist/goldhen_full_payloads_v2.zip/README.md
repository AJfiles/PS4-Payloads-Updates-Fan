# Payloads userland para GoldHEN (PS4)

Este proyecto genera payloads raw para cargar por BinLoader de GoldHEN. Usa una sola base de código por función y no depende de offsets de kernel. Son **universales por diseño, condicionados a interfaces verificadas**, no una promesa de compatibilidad total. Cada payload comprueba UID 0 y sandbox inactivo; aborta si no tiene ese contexto. Fan depende además de `/dev/icc_fan`; updates actúa únicamente sobre dos rutas estándar bajo `/update`.

## Binarios

- `fan_threshold_50/55/60/65/70/75/80_universal.bin`: aplica el umbral solicitado mediante GET de la tabla ICC de 28 bytes, modifica solo byte 5, hace SET y verifica por GET.
- `fan_default_universal.bin`: aplica 79; no restaura una copia previa.
- `disable_updates_universal.bin`: crea directorios señuelo en `/update/PS4UPDATE.PUP` y `/update/PS4UPDATE.PUP.net.temp`. Si encuentra ficheros regulares, los elimina antes de crear los señuelos; cualquier PUP ahí se pierde. Sobrevive al reinicio.
- `enable_updates_universal.bin`: solo hace `rmdir` de esas dos rutas canónicas cuando cada una es un directorio vacío. El modo y propietario son irrelevantes; si hay contenido o no puede comprobar que está vacío, aborta. Nunca borra recursivamente ni elimina archivos.

**Alcance:** el payload bloquea la descarga del PUP de actualización del sistema mediante esas dos rutas. No bloquea parches de juegos ni actualizaciones de aplicaciones, que usan otras rutas y mecanismos.

Todos notifican el resultado y envían log TCP al PC configurado al compilar. Los mensajes se muestran como notificación GoldHEN/PS4. El límite del campo de mensaje del SDK es 1024 bytes.

## Portabilidad y condiciones de ejecución del Fan

El binario de ventilador **no depende del firmware ni de offsets de kernel**, sino del cumplimiento estricto de **cuatro condiciones en runtime**:
1. Un cargador de BIN crudo (BinLoader de GoldHEN u equivalente).
2. Contexto de ejecución privilegiado: UID 0 y sandbox inactivo (`is_in_sandbox() == 0`).
3. Presencia del dispositivo de caracteres `/dev/icc_fan`.
4. Soporte operativo de los ioctls `_IOWR` de la tabla ICC (`0xC01C8F08` GET y `0xC01C8F07` SET).

**Alcance de verificación:**
- **VERIFICADO:** Exclusivamente en hardware real en PS4 Pro, firmware 9.00, con GoldHEN 2.4b18.10.
- **Indicios favorables (5.05–11.00):** La existencia de payloads originales y WebRTE en este rango de firmwares avala la presencia de la interfaz ICC, aunque no se ha ejecutado prueba en otros modelos ni revisiones de placa.
- **Firmwares > 11.00:** Solo existen builds comunitarios sin verificar por nuestra parte.
- **Comportamiento ante precondiciones no cumplidas:** El payload aborta limpiamente sin tocar hardware e indicando el motivo exacto en la notificación y en el log TCP.
- **Matiz y limitación honesta:** Como exigimos un GET previo obligatorio para preservar los restantes 27 bytes de la tabla ICC, cualquier entorno o build futuro que exponga el nodo `/dev/icc_fan` pero solo admita SET (o falle en el GET) provocará el aborto preventivo de nuestro payload, mientras que el payload original (que escribe a ciegas sin GET) funcionaría. Se asume conscientemente esta limitación en favor de la seguridad absoluta del hardware.
- **Rendimiento térmico:** Los payloads universales **NO enfrían más que los originales**. Modifican exactamente el mismo byte 5 con idénticos valores numéricos de umbral y producen las mismas temperaturas operativas; su ventaja radica en la seguridad del buffer (64 bytes frente a 10), la preservación de la tabla y la reversión verificada.

## Variantes de Updates: Minimalista v1 vs. Full v2

- **v1 Minimalista (Congelado, hashes `0a3ae44c...` y `c7cb5370...`):**
  - Aplica exclusivamente la **Capa 1 (Filesystem)**: directorios señuelo en `/update/PS4UPDATE.PUP` y `.net.temp`.
  - Alcance: Bloquea estrictamente la descarga del PUP de actualización del sistema operativo.
  - Impacto en red: Cero. Deja PSN, PlayStation Store, juego online y parches de juegos 100% intactos.
- **v2 Full (`disable_updates_full.bin` y `enable_updates_full.bin` — VERIFICADO en hardware en PS4 Pro 9.00):**
  - Integra las tres capas en un único binario con reporte individual y degradación elegante:
    1. **Capa 1 (Filesystem):** Señuelos vacíos en `/update/PS4UPDATE.PUP` y `.net.temp`.
    2. **Capa 2 (Ajustes del Sistema):** Control de descargas automáticas en segundo plano (`SCE_REGMGR_ENT_KEY_SYSTEM_UPDATE_auto_download = 0x02800500`: `0`=OFF, `1`=ON).
    3. **Capa 3 (Entorno de Red):** Conmutación del NP Environment de sistema (`SCE_REGMGR_ENT_KEY_NP_env = 0x19800000`: `"noupdt"` para bloqueo, `"np"` para restauración).
  - **Inmediatez del corte de red (VERIFICADO):** Comprobado en vivo en hardware: tras ejecutar `disable_updates_full.bin`, la comprobación en *Ajustes > Actualización del software del sistema* falla de inmediato sin detectar actualización (Caso A), confirmando que el shell no cachea el entorno NP y el corte opera en caliente sin requerir reinicio.
  - **Persistencia tras reinicio de valores escritos por payload (VERIFICADO):** Medido empíricamente en hardware con la sonda dual tras un reinicio completo en frío y recarga de GoldHEN (`NP_env="noupdt"` y `auto_download=0` en `analysis/probe_np_dual_post_reboot.txt`). Se confirma que las escrituras por `SetStr`/`SetInt` persisten tras reinicio completo y recarga de GoldHEN (verificado) en `/system_data/settings/system.dat` sin necesidad de reaplicar el payload tras reiniciar.
  - **Aviso explícito de impacto:** La Capa 3 rompe de forma deliberada el acceso a PSN, PlayStation Store, inicio de sesión de cuenta online y descarga de parches de juegos. Quien desee mantener funciones de red debe utilizar exclusivamente el par v1 minimalista.
  - **Degradación elegante y rollback por capa:** Si `libSceRegMgr.sprx` no está disponible o falla el acceso al registro, la Capa 1 siempre se aplica y se reporta (`Updates: 1/3 — registro no disponible`). Si una capa de registro falla su verificación, se revierte únicamente dicha capa sin deshacer las capas previas exitosas.
  - ⚠️ **AVISO CRÍTICO TRAS ENABLE:** Tras ejecutar `enable_updates_full.bin`, la consola queda **TOTALMENTE EXPUESTA** a descargar e instalar actualizaciones oficiales de firmware (señuelos fuera, auto_download ON, NP=np). **No dejar la consola en este estado.** Al terminar la tarea online o de actualización, reaplicar inmediatamente `disable_updates_full.bin`.
  - Para instrucciones prácticas de uso en una página, consultar [docs/QUICKSTART.md](docs/QUICKSTART.md).
  - **Herramienta de diagnóstico:** `write_verify_noop.bin` es una herramienta de diagnóstico interno para validar primitivas de escritura sin cambiar estado, **NO forma parte de la suite de uso diario**.
  - **Manifiesto de binarios v2 (`payloads/build_v2/SHA256SUMS.txt`):**
    - `write_verify_noop.bin`: `9fcde094b5c0fa6134a9bee0f1823a4506f9549b55778e892f232a101289c6bb` (DIAGNÓSTICO)
    - `disable_updates_full.bin`: `d164f3ee4df8e42b67a979f4e5c00101789a842615610273c7046bf9a1ad1043`
    - `enable_updates_full.bin`: `714ed6707080f5a70c00d1c2ca8d9b7e8ad2988ac39dfbac6a9123cacbcd6990`
    - `np_readonly_dual_probe.bin`: `a8722089a2e79183480af16bbed9989df88e337a63b0311be34d051f49c90b80` (SONDA DUAL REGISTRO)

## Estado de evidencia

**VERIFICADO:** PS4 Pro 9.00 + GoldHEN 2.4b18.10, contexto BinLoader root sin sandbox, nodo ICC y GET; originales fan60/default; todos los umbrales universales y default medidos. La sonda C, tomada tras el reinicio reportado y antes de los smoke tests posteriores, leyó `0x3C` dos veces, confirmando que ese ajuste sobrevivió al reinicio y a recargar GoldHEN. El default aplica 79, el valor stock observado; vuelve a ese valor, no restaura una copia previa. El signo `°` se vio correctamente en la notificación de E2.

**VERIFICADO en esta consola:** los umbrales 50, 55, 60, 65, 70, 75, 80 y default 79 pasaron medidas individuales; cada captura cambió solo el byte 5 y la sonda leyó el mismo valor. 80 mostró el aviso de que supera el stock observado. El estado final quedó en 79. Las capturas están en [analysis](analysis/FAN_SMOKE_TESTS.md).

**ALTA CONFIANZA TÉCNICA, NO GARANTIZADO:** otras PS4 con GoldHEN que expongan root sin sandbox, `/dev/icc_fan`, los ioctls `0xC01C8F07/08` y las rutas `/update` estándar. Los originales de updates de 5.05 a 11.00 usaron las mismas rutas; los originales fan de 5.05 y 9.00 usaron `/dev/icc_fan`, pero el payload nuevo de fan solo está verificado en 9.00. Todo BIN nuevo comprueba sus precondiciones en runtime y aborta sin operar si no las cumple.

**DESCONOCIDO/EXPERIMENTAL:** builds comunitarios, 14.02/Afterglow, GoldHEN antiguo, otros loaders y modelos no probados. No hay offsets de kernel; la dependencia real son las interfaces y permisos disponibles en runtime. La versión mínima compatible de GoldHEN se desconoce.

## Seguridad y límites

Los originales del fan y los cuatro BIN del repo de referencia (60/70/80/85) pasan 10 bytes a un ioctl `_IOWR` de 28 bytes; la llamada puede leer 18 bytes fuera del buffer y copiar 18 bytes de vuelta más allá de él. Los BIN nuevos usan GET-modify-SET con buffer de 64 bytes y solo cambian el byte 5; ofrecen 50–80 y default 79. El valor 80 supera el stock observado de 79: no es refrigeración extra. El umbral ICC es un objetivo del ventilador, no un techo duro de temperatura ni una protección térmica. Ningún BIN nuevo contiene `kexec`, syscall 11 ni offsets de kernel.

El bloqueo de updates cambia el sistema de archivos y persiste al apagar. Solo bloquea el PUP de actualización del sistema; no bloquea parches de juegos ni actualizaciones de aplicaciones. `disable` elimina primero cualquier fichero regular que encuentre en las dos rutas, así que un PUP descargado allí se pierde, y luego crea los directorios señuelo. `enable` retira solo directorios vacíos en las rutas exactas mediante `rmdir`; modo y propietario no participan en la decisión. Si encuentra ficheros, contenido inesperado o no puede confirmar que estén vacíos, aborta. No se cambia DNS. El roundtrip de los BIN reconstruidos está en [analysis/probe_F_recheck.txt](analysis/probe_F_recheck.txt); el roundtrip histórico anterior se conserva en [analysis/probe_F.txt](analysis/probe_F.txt).

El desensamblado de los payloads originales muestra que `disable` pasa `0x309` a `mkdir`, equivalente a octal `01411`; eso no explica los modos observados `0777` y `0555`, y `umask` solo puede quitar bits. La causa queda **NO RESUELTA**: pudo haber un `chmod` posterior, normalización del filesystem o creación por otro payload. El modo no cambia el bloqueo: lo determinante es que la ruta sea un directorio en lugar de un fichero PUP. La hipótesis de que `0555` impide `rmdir` está descartada; FreeBSD verifica que el directorio esté vacío y la escritura/permisos del padre, no el modo del hijo ([manual `rmdir(2)`](https://man.freebsd.org/cgi/man.cgi?query=rmdir&sektion=2&manpath=FreeBSD+14.0-RELEASE)).

Consulta [docs/INSTALL.md](docs/INSTALL.md) para la carga y [docs/TESTING.md](docs/TESTING.md) para las medidas secuenciales. Los resultados de hardware están en `analysis/probe_*.txt`; los hashes están en `payloads/build/SHA256SUMS.txt`.

La sonda de compatibilidad y su plantilla están en [docs/PROBE.md](docs/PROBE.md) y [docs/PROBE_REPORT_TEMPLATE.md](docs/PROBE_REPORT_TEMPLATE.md). Recompila la sonda con la IPv4 de tu propio PC antes de cargarla. Para informar un fallo o confirmar otro firmware, usa la plantilla de reporte.

La capa ELF/`elfldr` y NP Environment quedan aparcadas como proyectos separados; ver [propuesta de builds duales](analysis/DUAL_BUILD_PROPOSAL.md) y [nota NP Environment](research/NP_ENVIRONMENT.md). El upstream fijado de `elfldr` declara hasta 14.00 y requiere `remote_lua_loader`; no es drop-in para Afterglow y aquí no se promete soporte para 14.02.
