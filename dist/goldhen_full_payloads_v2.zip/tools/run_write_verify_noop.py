#!/usr/bin/env python3
"""Lanza el receptor TCP y envía write_verify_noop.bin a la PS4 (Paso 1)."""
import socket
import threading
import time
import sys
import hashlib
from pathlib import Path

PAYLOAD_PATH = Path('payloads/build_v2/write_verify_noop.bin')
EXPECTED_HASH = '9fcde094b5c0fa6134a9bee0f1823a4506f9549b55778e892f232a101289c6bb'
PS4_IP = '192.168.20.39'
PS4_PORT = 9090
PC_HOST = '0.0.0.0'
PC_PORT = 9090
OUTPUT_FILE = Path('analysis/probe_write_verify_noop.txt')

# 1. Verificar hash del binario antes de enviar
data = PAYLOAD_PATH.read_bytes()
h = hashlib.sha256(data).hexdigest()
if h != EXPECTED_HASH:
    print(f'ERROR: Hash mismatch: {h} != {EXPECTED_HASH}', file=sys.stderr)
    sys.exit(1)
print(f'Hash verificado: {h} (coincide exactamente con el valor auditado)')

# 2. Iniciar servidor TCP receptor
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((PC_HOST, PC_PORT))
server.listen(1)
server.settimeout(30.0)
print(f'Receptor escuchando en {PC_HOST}:{PC_PORT} (timeout 30s)...')

report_data = bytearray()
send_error = []

def sender_thread():
    time.sleep(0.6)
    print(f'Enviando {len(data)} bytes a la PS4 ({PS4_IP}:{PS4_PORT})...')
    try:
        with socket.create_connection((PS4_IP, PS4_PORT), timeout=10.0) as sock:
            sock.sendall(data)
            sock.shutdown(socket.SHUT_WR)
        print('Envío TCP completado con éxito hacia la PS4.')
    except Exception as exc:
        print(f'ERROR en el envío a la PS4: {exc}', file=sys.stderr)
        send_error.append(str(exc))

t = threading.Thread(target=sender_thread)
t.start()

try:
    conn, peer = server.accept()
    print(f'Conexión entrante desde {peer[0]}:{peer[1]}')
    with conn:
        conn.settimeout(10.0)
        while True:
            chunk = conn.recv(2048)
            if not chunk:
                break
            report_data.extend(chunk)
except socket.timeout:
    print('ERROR: Timeout esperando reporte de la PS4 (30s).', file=sys.stderr)
    sys.exit(2)
except Exception as exc:
    print(f'ERROR en el receptor: {exc}', file=sys.stderr)
    sys.exit(3)
finally:
    server.close()
    t.join()

if send_error:
    print(f'Fallo en sender: {send_error}', file=sys.stderr)
    sys.exit(4)

report_text = report_data.decode('utf-8', errors='replace')
OUTPUT_FILE.write_text(report_text, encoding='utf-8')
print(f'\n--- Reporte guardado en {OUTPUT_FILE} ({len(report_data)} bytes) ---')
print(report_text)
print('--- Fin del reporte ---')
