# Diff funcional y fallback de escalada en los BIN originales

Análisis estático de los 27 BIN en carpetas de firmware raíz. No se ejecutaron archivos. Los offsets son posiciones del BIN raw, desde cero. La detección identifica wrappers directos que cargan el número de syscall en RAX y saltan al dispatcher común; no confunde la mera instrucción `syscall` con el número empleado.

## Evidencia por binario

| BIN | bytes | ioctl SET 8F07 / GET 8F08 | wrappers syscall11 | llamadas directas al wrapper 11 | `syscall` instrucciones | rutas literales |
|---|---:|---:|---|---:|---:|---|
| `5.05/disableupdates.bin` | 5984 | 0 / 0 | 0xd23 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `5.05/enableupdates.bin` | 5944 | 0 / 0 | 0xd01 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `6.72/disableupdates.bin` | 6793 | 0 / 0 | 0x750 | 2 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `6.72/enableupdates.bin` | 6758 | 0 / 0 | 0x72e | 2 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `7.02/disableupdates.bin` | 9875 | 0 / 0 | 0x135a | 2 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `7.02/enableupdates.bin` | 9840 | 0 / 0 | 0x1338 | 2 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `7.55/disableupdates.bin` | 6804 | 0 / 0 | 0xf91 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `7.55/enableupdates.bin` | 6772 | 0 / 0 | 0xf6f | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `9.00/disableupdates.bin` | 7292 | 0 / 0 | 0x10c3 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `9.00/enableupdate.bin` | 7260 | 0 / 0 | 0x10a1 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `11.00/disable-updates.bin` | 7852 | 0 / 0 | 0x2ba | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `11.00/enable-updates.bin` | 7828 | 0 / 0 | 0x2a0 | 1 | 1 | /update/PS4UPDATE.PUP.net.temp, /update/PS4UPDATE.PUP |
| `Fan 5.05/fan50.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan55.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan60.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan65.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan70.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan75.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 5.05/fan80.bin` | 4880 | 1 / 0 | 0x8ad | 0 | 1 | /dev/icc_fan |
| `Fan 9.00/fan50.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan55.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan60.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan65.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan70.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan75.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fan80.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |
| `Fan 9.00/fanDefault.bin` | 7472 | 1 / 0 | 0x11c5 | 1 | 1 | /dev/icc_fan |

## Interpretación y equivalencia funcional

- La presencia de un wrapper syscall 11 confirma que el BIN incluye físicamente el portal kexec, aun cuando el flujo de `jailbreak()` pueda omitirlo en runtime si ya se ejecuta con UID 0 y fuera del sandbox. No concluye por sí sola que cada payload lo alcance. La columna de llamadas al wrapper mide referencias directas recuperables en el desensamblado lineal; las indirectas/no reconocidas quedan sin atribuir.
- En los fan, la función de usuario abre `/dev/icc_fan` y llama SET `0xC01C8F07`; el umbral está en el byte 5 de un objeto de 10 bytes inicializados. El tamaño ioctl codifica 28 bytes. Los 18 bytes superiores no son constantes conocidas y no se atribuye contenido estable a ellos.
- En updates, las cadenas y secuencias de syscall deben leerse junto con la fuente fijada Scene-Collective: rutas `/update/PS4UPDATE.PUP.net.temp` y `/update/PS4UPDATE.PUP`, `unlink/rmdir/mkdir` para disable y `unlink/rmdir` para enable. Los seis builds comparten destino funcional; los blobs no son un simple flag de 1 byte.
- La diferencia 9.797 vs 4.880 bytes no se interpreta como ~4.900 bytes de kexec sin medir las regiones. Esta tabla informa offsets concretos del wrapper 11; no adjudica automáticamente padding, librería, tablas ni código a una función sin símbolo/xref suficiente.

## Flujo del enable original 9.00

En `9.00/enableupdate.bin` (SHA-256 `e8d432e1ddaf18bc15ae4b048e5577b6b33564e6bb05c1840abe04fb4f5d9078`), `_main` carga `/update/PS4UPDATE.PUP.net.temp` desde el offset de datos `0x1480` y llama al wrapper syscall 10 (`unlink`) en `0x933`, seguido de syscall 137 (`rmdir`) en `0x9b7` (call sites `0x2f` y `0x40`). Repite la secuencia para `/update/PS4UPDATE.PUP` en offset de datos `0x149f` (call sites `0x4c` y `0x58`). La secuencia principal no comprueba los retornos antes de continuar ni confirma al final que ambas rutas estén ausentes. Esto explica cómo puede dejar una ruta sin retirar si `unlink`/`rmdir` falla; el intento posterior de descarga que el usuario describe pudo limpiar PUP, pero esa causalidad es probable, no demostrada.

## Métricas de similitud de grupos

La matriz byte/alineación ya está en [DIFF_MATRIX.md](DIFF_MATRIX.md). Para fan 5.05 los siete umbrales conservan el mismo tamaño y cambian el byte de parámetro `0x173` y un texto corto; en fan 9.00 los umbrales/default comparten 7.472 bytes y el parámetro está en `0x1D28`. Las operaciones de update por versión tienen código de tamaño y composición distintos; se debe comparar el comportamiento (syscalls, argumentos, rutas) y no igualdad de bytes.

## Hashes

| BIN | SHA-256 |
|---|---|
| `5.05/disableupdates.bin` | `d29b66e9396281e4596e8cfa68c9ce0c252b02342d7710697edf60688262ccfa` |
| `5.05/enableupdates.bin` | `a621f112f2bbf1eda4f48fa4170849e965cbb7ad26560bba0a978f206cec659c` |
| `6.72/disableupdates.bin` | `2b6754cb87f2f9a530822104f34efcba97f292cd6432fc3c9d2abae2520d1097` |
| `6.72/enableupdates.bin` | `672cfea9258fb65db4660ce9c8f2feb5ea99edc5b60e2871e5d9c91fe393e598` |
| `7.02/disableupdates.bin` | `3d97998ad1f35ddde8097c49abce2a4cf1cb7cab4719f0a61688ead5f38e0440` |
| `7.02/enableupdates.bin` | `6d05388998e09d5f186e80cdd605f1ed527daf70ae4fdd1252602486ebe44d44` |
| `7.55/disableupdates.bin` | `0d05e4c40942b5aadbeed08d620fb57a93c75671d2dcb4d00dfa4c3de26c73f2` |
| `7.55/enableupdates.bin` | `15a02cebf0e6634a6b47bebee27fa532002257063d804629f496ab00866a170f` |
| `9.00/disableupdates.bin` | `e1554212fa02160663c3ea824713e78ecc3dd1b65f08118ab3639c2e1ac091fd` |
| `9.00/enableupdate.bin` | `e8d432e1ddaf18bc15ae4b048e5577b6b33564e6bb05c1840abe04fb4f5d9078` |
| `11.00/disable-updates.bin` | `c8c9f8a18c58713d621a7a19f77cf12e3b641b46c0d6109e5fcaf54fb21450fc` |
| `11.00/enable-updates.bin` | `1bbb05dd98de9cfaff89158214da3eebdab5b79354fa12231f7b4643faa01ea9` |
| `Fan 5.05/fan50.bin` | `632ed4051723efaddea0458a15bc8fc626caae0770f442b2e260c634ec480261` |
| `Fan 5.05/fan55.bin` | `cd70b216a6a3ffec9d3ef79c787fb94135c96476f5d5f1254f6a7d163dc71843` |
| `Fan 5.05/fan60.bin` | `bbc109ed6f6dcf5def9ad64b1cdf2de3f4756edecefe351096cfd7fddb5fa2b2` |
| `Fan 5.05/fan65.bin` | `f097570390d1b064bb4e79c99ae6b0d5356f16d9c8e1eb4d59606da3cb489959` |
| `Fan 5.05/fan70.bin` | `74fdb849260521f384647c64291aa38c19d0f1b18e1c26c907a9641905e6d190` |
| `Fan 5.05/fan75.bin` | `525a737e193d7aea8e6f67dd7fd595272c565487ccd34d4aff6a5d45b09198a3` |
| `Fan 5.05/fan80.bin` | `c6768dab83163fa4045a59b3aea3d51e5602ff5ccce4e17c7f29615223239395` |
| `Fan 9.00/fan50.bin` | `7b5d5b367e653bbc4ecbe0b977832c14d418a391bac02708e62cd880ddeac4e5` |
| `Fan 9.00/fan55.bin` | `9d8c2aa6a3e424328bd040e9122370f8c9cc7182bc4da21142d8cfbc43c70367` |
| `Fan 9.00/fan60.bin` | `3fce5c84aa16e442f0d1f756d595fc9c773cef588a8f7b26b4934140f8bc69c2` |
| `Fan 9.00/fan65.bin` | `d0345cc8506ce861f3f496d6832946cfe5b004dbf2efa2b9ea317e3b382ac6ec` |
| `Fan 9.00/fan70.bin` | `afe9c60b51fa41deb6b9aa1044c45a92789264606ecfe5d68adcae425567465b` |
| `Fan 9.00/fan75.bin` | `7a9539f7321090f715b661d5a12094a7490f91fd1e1fe3e9398c5aec68e127a0` |
| `Fan 9.00/fan80.bin` | `46e9074ec62498f2712be59838b120a9cdd5139e1f848b7fff85f27bd06cc57e` |
| `Fan 9.00/fanDefault.bin` | `75fd871fc09c49a18b8006b8120a5e2e407196f6cb03289b949fd50419bdeffc` |
