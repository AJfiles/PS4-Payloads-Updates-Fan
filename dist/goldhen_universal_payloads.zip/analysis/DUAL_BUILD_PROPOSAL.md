# Propuesta de build dual BIN / ELF

## Fuente upstream auditada

`ps4-payload-dev/elfldr`, commit `a4817404f5cb2d5c177b05cd5e4548b74e6c2725`, se descargó solo con los archivos necesarios en `research/sources/ps4-payload-dev-elfldr-a4817404f5cb/`. Su README dice que el flujo requiere primero un exploit kernel y `remote_lua_loader`; el servidor de ELF escucha por defecto en TCP 9021. El README del repositorio WPA-Libertario atribuye al artefacto incluido un rango 4.71–13.52.

El bootstrap upstream no es firmware-independiente: `bootstrap-elf.c` lee la versión de kernel, selecciona por `switch` y aplica pattern scan al kernel. El commit contiene casos concretos hasta `0x14000000` (14.00), pero no `0x14020000` (14.02). El binario `elfldr.elf` incluido por el repo puede tener otro historial/build y no convierte el upstream fijado en soporte 14.02. **No se recomienda declarar compatibilidad 14.02** con esta evidencia.

## Evaluación de las tres ventajas propuestas

| Afirmación | Veredicto | Evidencia y límite |
|---|---|---|
| Resolver SPRX/símbolos en runtime elimina syscalls fijos | Parcial | elfldr resuelve dependencias dinámicas/SPRX y símbolos del ELF. El payload puede importar APIs de libc/libkernel en vez de codificar números de syscall. El loader y su bootstrap sí contienen llamadas y resolución de kernel específicas; un payload que conserve wrappers syscall directos tampoco deja de fijar números automáticamente. |
| Un ELF elimina por construcción el EFAULT por punteros | Parcial | `elfldr.c` carga `ET_DYN`/`ET_EXEC` y su ruta procesa `R_X86_64_RELATIVE`; la ruta de dynlib delega dependencias/relocaciones al sistema. Solo corrige punteros si el compilador/linker emite una relocación soportada y elfldr conserva/procesa su metadata. El formato ELF por sí solo no evita relocaciones ausentes o tipos no soportados. En nuestros diez ELF intermedios la auditoría encontró cero relocaciones y los raw muestran RIP-relative, de modo que la corrección actual no depende de ELF. |
| ELF amplía el alcance frente a GoldHEN upstream | Sí, condicionado al loader/exploit | El transporte 9021 no exige GoldHEN BinLoader, pero sí requiere una cadena de exploit + remote_lua_loader + elfldr compatible con el firmware. El rango no supera el firmware reconocido por el bootstrap; 14.02 queda fuera en el commit auditado. |

## Diseño recomendado si se autoriza implementar

Mantener un único código de lógica y una capa pequeña de plataforma. Construir (a) BIN raw para GoldHEN 9090 usando las llamadas directas ya auditadas y (b) ELF `ET_DYN` con ABI/homebrew SDK compatible con elfldr, importando APIs de sistema en lugar de números syscall directos. No reutilizar sin adaptación los artefactos raw como ELF ni afirmar que el mismo enlace binario sirve en ambos loaders.

El upstream fija el toolchain mediante `PS4_PAYLOAD_SDK` e incluye `toolchain/orbis.mk`; su Makefile usa `-fPIC` y enlaza módulos SPRX para el servidor (`libSceSsl2`, `libSceHttp2`). Esto identifica la ruta reproducible del SDK, pero no demuestra por sí solo que nuestro ELF de aplicación importe las mismas bibliotecas. El ELF necesita headers/segmentos ELF64 válidos, relocs soportadas, dependencias SPRX resolubles y un runtime PS4 compatible. El código debe comprobar `getuid()==0` y sandbox ausente en runtime y abortar antes de tocar estado si no cumple. Para operaciones de filesystem, la propuesta es importar funciones exportadas de libc/libkernel (por ejemplo `open`, `ioctl`, `mkdir`, `rmdir`) y comprobar sus prototipos, SPRX/NIDs y errno en el ABI de elfldr. La identidad exacta de los exports/NIDs necesarios aún no está confirmada en el checkout; no se debe asumir que los imports del BIN raw funcionan en proceso ELF.

## Prueba en la PS4 9.00

La prueba requiere que el usuario cargue la cadena requerida por elfldr para 9.00 (exploit kernel y remote_lua_loader), inicie elfldr en la consola y envíe un ELF al puerto 9021. Primero debe ser un ELF de lectura que informe identidad/firmware y resuelva/importa las funciones necesarias; no debe hacer ioctl SET ni operaciones en `/update`. Luego probar operaciones no destructivas. El BinLoader GoldHEN 9090 y la PS4 9.00 actual siguen siendo la ruta probada. No se ejecutó elfldr ni se contactó la consola en esta investigación.

**Recomendación:** documentar dual build como línea futura, no sustituir el BIN GoldHEN verificado. Antes de implementar ELF hacen falta: confirmar cadena y ABI exactos de `remote_lua_loader` en 9.00; fijar toolchain/SDK PS4 que produzca ELF con SPRX imports; revisar nombres/NIDs y permisos de las APIs; y crear una sonda ELF inocua. El loader amplía vías de carga en firmwares donde su bootstrap sí reconoce el kernel, pero no da universalidad total ni soporte 14.02.
