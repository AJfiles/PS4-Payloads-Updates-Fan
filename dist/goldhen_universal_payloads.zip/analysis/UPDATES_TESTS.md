# Evidencia funcional de bloqueo de descarga del PUP de sistema

Hardware: PS4 Pro, firmware 9.00, GoldHEN 2.4b18.10. Fecha reportada: 2026-11-19.

## Resultado comunicado por el usuario — VERIFICADO EN HARDWARE (reporte del usuario)

Con el bloqueo de updates activo y `NP environment = np`, la consola detectó la actualización del sistema. Al intentar descargarla, mostró **“No se ha podido descargar”**. El usuario realizó la prueba; no se ejecutó desde el PC durante esta sesión.

Esto verifica el fallo de descarga del PUP del sistema en esa configuración. No demuestra bloqueo de parches de juegos ni actualizaciones de aplicaciones; esas funciones usan otras rutas/mecanismos.

## Estado actual de rutas según la sonda ampliada

La captura `analysis/probe_F_idempotence4.txt` informa que ambas rutas son directorios root-owned `0555`, vacíos según `getdents` (`entries.count=0`, `entries.status=OK`). Un listado FTP de solo lectura en EPSV y PASV mostró solo `.` y `..` en cada ruta. F0 envió el BIN SHA-256 `32614e4cec4f24554104a2ac84d0231267a0c4587aa6bce345006dfe8b6fc9d2`, que en esa versión reconocía solo directorios root-owned `0777` o `0555`; verificó ambas y las preservó con estado `DISABLED`. La sonda previa y posterior mostró `0555` y conteo cero. F0 no probó la creación de una ruta ausente porque ambas ya existían. El nuevo criterio se compiló en los BIN de updates y se revalidó en F_RECHECK.

F0 está verificado como operación idempotente sobre ambas rutas existentes con la lógica histórica. El roundtrip F está completado con los binarios previos: con la confirmación del operador de `NP environment = noupdt` y descargas automáticas desactivadas, enable hizo `rmdir` exitoso en ambas rutas vacías; disable las recreó como directorios vacíos `0777`. La sonda final lo confirmó. El ajuste `noupdt` fue declarado por el operador y no se leyó independientemente desde el payload. La revalidación de los BIN reconstruidos consta en [probe_F_recheck.txt](probe_F_recheck.txt).

Una lectura FTP posterior en modo pasivo confirmó ambas rutas como directorios root-owned `0777` con solo `.` y `..`; `/dev/icc_fan` se listó como dispositivo de caracteres `0666`. Solo se usaron comandos `LIST`, sin escrituras. El caso mixto PUP ausente + `.net.temp` presente queda cubierto por composición de las dos ramas independientes verificadas; no se ejecutó una medida mixta de hardware.

## F_RECHECK — BIN reconstruidos

El recheck de los dos BIN corregidos está en [probe_F_recheck.txt](probe_F_recheck.txt). La sonda previa confirmó las dos rutas como directorios vacíos `0777`; el nuevo enable reportó `EXACT_PATH_EMPTY_DIRECTORY`, hizo `rmdir` exitoso sobre ambas y la sonda confirmó que quedaron ausentes. El nuevo disable recreó las dos rutas vacías, y la sonda final las confirmó como directorios vacíos `0777`. No se usó una condición por modo o propietario; las evidencias concretas anteriores muestran 0777, pero el criterio implementado es ruta exacta + directorio + vacío.
