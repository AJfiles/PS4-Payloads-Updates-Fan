#!/usr/bin/env python3
"""Empaqueta BIN, sonda y documentación con un manifiesto SHA-256."""
from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
ARCHIVE = DIST / "goldhen_universal_payloads.zip"
PAYLOAD_DIR = ROOT / "payloads" / "build"
PROBE = ROOT / "probe" / "build" / "goldhen_readonly_probe.bin"

DOCS = [
    ("README.md", "README.md"),
    ("docs/INSTALL.md", "docs/INSTALL.md"),
    ("docs/TESTING.md", "docs/TESTING.md"),
    ("docs/PROBE.md", "docs/PROBE.md"),
    ("docs/PROBE_REPORT_TEMPLATE.md", "docs/PROBE_REPORT_TEMPLATE.md"),
    ("docs/PROBE_COMPARE_TEMPLATE.md", "docs/PROBE_COMPARE_TEMPLATE.md"),
    ("research/PORTABILITY.md", "research/PORTABILITY.md"),
    ("research/README.md", "research/README.md"),
    ("research/TOOLING.md", "research/TOOLING.md"),
    ("analysis/FAN_SMOKE_TESTS.md", "analysis/FAN_SMOKE_TESTS.md"),
    ("analysis/C_AND_F_AUDIT.md", "analysis/C_AND_F_AUDIT.md"),
    ("analysis/P2_FUNCTIONAL_DIFF.md", "analysis/P2_FUNCTIONAL_DIFF.md"),
    ("analysis/UPDATES_TESTS.md", "analysis/UPDATES_TESTS.md"),
    ("analysis/TEST_STATUS.md", "analysis/TEST_STATUS.md"),
    ("analysis/DUAL_BUILD_PROPOSAL.md", "analysis/DUAL_BUILD_PROPOSAL.md"),
    ("research/NP_ENVIRONMENT.md", "research/NP_ENVIRONMENT.md"),
    ("payloads/updates_control.c", "payloads/updates_control.c"),
    ("payloads/update_syscalls.c", "payloads/update_syscalls.c"),
    ("payloads/enable_syscalls.c", "payloads/enable_syscalls.c"),
    ("payloads/payload_runtime.c", "payloads/payload_runtime.c"),
    ("payloads/payload_runtime.h", "payloads/payload_runtime.h"),
    ("payloads/kernel_syscalls.c", "payloads/kernel_syscalls.c"),
    ("probe/goldhen_readonly_probe.c", "probe/goldhen_readonly_probe.c"),
    ("probe/probe_syscalls.c", "probe/probe_syscalls.c"),
    ("tools/build_readonly_probe.py", "tools/build_readonly_probe.py"),
    ("tools/audit_readonly_probe.py", "tools/audit_readonly_probe.py"),
    ("tools/receive_probe.py", "tools/receive_probe.py"),
    ("tools/send_payload.py", "tools/send_payload.py"),
    ("tools/run_measurement.py", "tools/run_measurement.py"),
    ("tools/build_universal_payloads.py", "tools/build_universal_payloads.py"),
    ("tools/audit_universal_payloads.py", "tools/audit_universal_payloads.py"),
    ("tools/package_release.py", "tools/package_release.py"),
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    manifest_path = PAYLOAD_DIR / "SHA256SUMS.txt"
    manifest = {}
    for line in manifest_path.read_text(encoding="ascii").splitlines():
        sha, name = line.split(maxsplit=1)
        manifest[Path(name.strip()).name] = sha
    expected = {
        "disable_updates_universal.bin", "enable_updates_universal.bin",
        "fan_threshold_50_universal.bin", "fan_threshold_55_universal.bin",
        "fan_threshold_60_universal.bin", "fan_threshold_65_universal.bin",
        "fan_threshold_70_universal.bin", "fan_threshold_75_universal.bin",
        "fan_threshold_80_universal.bin", "fan_default_universal.bin",
    }
    if set(manifest) != expected:
        raise SystemExit("El manifiesto de payloads no contiene exactamente los diez BIN esperados")

    members: list[tuple[str, bytes]] = []
    binary_hashes: list[tuple[str, str]] = []
    for name in sorted(expected):
        path = PAYLOAD_DIR / name
        actual = digest(path)
        if actual != manifest[name]:
            raise SystemExit(f"Hash no coincide con payloads/build/SHA256SUMS.txt: {name}")
        archive_name = f"bin/{name}"
        members.append((archive_name, path.read_bytes()))
        binary_hashes.append((actual, archive_name))

    probe_sha = digest(PROBE)
    members.append(("probe/goldhen_readonly_probe.bin", PROBE.read_bytes()))
    binary_hashes.append((probe_sha, "probe/goldhen_readonly_probe.bin"))

    for source, archive_name in DOCS:
        path = ROOT / source
        if not path.is_file():
            raise SystemExit(f"Falta un artefacto requerido para el paquete: {source}")
        members.append((archive_name, path.read_bytes()))

    # Incluye evidencia útil sin revelar las IPv4 privadas de esta LAN.
    report_names = [
        "probe_A.txt", "probe_B.txt", "probe_C.txt", "probe_D.txt", "probe_E.txt",
        "probe_E2.txt", "probe_F.txt", "probe_F_idempotence.txt", "probe_F_idempotence2.txt",
        "probe_F_idempotence3.txt", "probe_F_idempotence4.txt", "probe_F_recheck.txt", "probe_PRE_F0.txt",
        "probe_T50.txt", "probe_T55.txt",
        "probe_T65.txt", "probe_T70.txt", "probe_T75.txt", "probe_T80.txt",
        "probe_TDEFAULT.txt",
    ]
    for report_name in report_names:
        source = f"analysis/{report_name}"
        archive_name = source
        path = ROOT / source
        if path.is_file():
            public_text = path.read_text(encoding="utf-8", errors="replace")
            public_text = public_text.replace("192.168.20.39", "<IP_PS4>")
            public_text = public_text.replace("192.168.20.48", "<IP_PC>")
            members.append((archive_name, public_text.encode("utf-8")))

    sums = "".join(f"{sha}  {name}\n" for sha, name in sorted(binary_hashes, key=lambda item: item[1]))
    manifest_out = DIST / "SHA256SUMS.txt"
    manifest_out.write_text(sums, encoding="ascii", newline="\n")
    members.append(("SHA256SUMS.txt", manifest_out.read_bytes()))

    DIST.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for archive_name, content in members:
            archive.writestr(archive_name, content)

    print(f"archive={ARCHIVE}")
    print(f"members={len(members)} binaries={len(binary_hashes)}")
    print(f"sha256={digest(ARCHIVE)}")


if __name__ == "__main__":
    main()
