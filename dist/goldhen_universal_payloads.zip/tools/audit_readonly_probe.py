#!/usr/bin/env python3
"""Auditoría estática ELF/BIN de la sonda; no ejecuta código PS4."""
from __future__ import annotations

import struct
import argparse
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

ROOT = Path(__file__).resolve().parents[1]
ELF = ROOT / "work" / "readonly-probe-build" / "goldhen_readonly_probe.elf"
BIN = ROOT / "probe" / "build" / "goldhen_readonly_probe.bin"
ALLOWED_SYSCALL_NUMBERS = {4, 5, 6, 54, 188, 272, 395, 585, 591, 594}
FORBIDDEN_SYSCALL_NUMBERS = {10, 11, 21, 22, 37, 136, 137}


def parse_symbols(data: bytes) -> dict[str, tuple[int, int]]:
    if data[:4] != b"\x7fELF" or data[4] != 2 or data[5] != 1:
        raise ValueError("ELF temporal no es x86-64 little-endian")
    shoff = struct.unpack_from("<Q", data, 40)[0]
    shentsize, shnum, shstrndx = struct.unpack_from("<HHH", data, 58)
    sections = []
    for i in range(shnum):
        off = shoff + i * shentsize
        sections.append(struct.unpack_from("<IIQQQQIIQQ", data, off))
    def cstr(blob: bytes, off: int) -> str:
        end = blob.find(b"\0", off)
        return blob[off:end if end >= 0 else len(blob)].decode("utf-8", "replace")

    by_name: dict[str, tuple[int, int]] = {}
    for sec in sections:
        sec_type, sec_off, sec_size, sec_link, sec_entsize = sec[1], sec[4], sec[5], sec[6], sec[9]
        if sec_type != 2 or sec_entsize == 0:  # SHT_SYMTAB
            continue
        strsec = sections[sec_link]
        strings = data[strsec[4]:strsec[4] + strsec[5]]
        for off in range(sec_off, sec_off + sec_size, sec_entsize):
            nameoff, info, other, shndx, value, size = struct.unpack_from("<IBBHQQ", data, off)
            if nameoff == 0 or shndx == 0:
                continue
            name = cstr(strings, nameoff)
            if name:
                by_name[name] = (value, size)
    return by_name


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-host", required=True, help="IPv4 incrustada en el BIN")
    args = parser.parse_args()
    import ipaddress
    try:
        expected_host = str(ipaddress.IPv4Address(args.report_host)).encode("ascii")
    except ipaddress.AddressValueError as exc:
        parser.error(f"--report-host debe ser una IPv4: {exc}")
    elf = ELF.read_bytes()
    raw = BIN.read_bytes()
    symbols = parse_symbols(elf)
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    instructions = list(md.disasm(raw, 0))
    dispatch = None
    for i, ins in enumerate(instructions[:-1]):
        if ins.mnemonic == "mov" and ins.op_str.replace(" ", "") == "r10,rcx" and instructions[i + 1].mnemonic == "syscall":
            dispatch = ins.address
            break
    if dispatch is None:
        raise SystemExit("AUDIT FAIL: no se identificó dispatcher syscall del SDK")
    syscall_numbers = set()
    wrappers = []
    for i in range(len(instructions) - 1):
        ins, nxt = instructions[i], instructions[i + 1]
        if ins.mnemonic == "mov" and ins.op_str.startswith("rax, ") and nxt.mnemonic == "jmp":
            try:
                number = int(ins.op_str.split(",", 1)[1].strip(), 0)
                target = int(nxt.op_str, 0)
            except ValueError:
                continue
            if target == dispatch:
                syscall_numbers.add(number)
                wrappers.append((ins.address, number))
    forbidden_present = sorted(syscall_numbers & FORBIDDEN_SYSCALL_NUMBERS)
    missing_wrappers = sorted(ALLOWED_SYSCALL_NUMBERS - syscall_numbers)
    forbidden_bytes = {
        "ioctl_set": bytes.fromhex("07 8f 1c c0"),
        "kexec_name": b"kexec",
        "jailbreak_name": b"jailbreak",
    }
    byte_hits = [name for name, pattern in forbidden_bytes.items() if pattern in raw]
    entry_is_e9 = raw[:1] == bytes((0xE9,))
    host_embedded = expected_host in raw
    print(f"raw_bytes={len(raw)} entry_e9={entry_is_e9}")
    print(f"syscall_dispatch=0x{dispatch:x} direct_numbers={sorted(syscall_numbers)}")
    print(f"forbidden_syscall_numbers={forbidden_present or 'none'}")
    print(f"elf_symbols={len(symbols)}")
    print(f"forbidden_raw_patterns={byte_hits or 'none'}")
    print(f"report_host_embedded={host_embedded}")
    if forbidden_present or byte_hits or missing_wrappers or not host_embedded:
        raise SystemExit(f"AUDIT FAIL: missing={missing_wrappers}")
    print("AUDIT PASS: no privileged escalation or destructive syscall stubs; read-only/getfsstat and guarded USB output stubs present")


if __name__ == "__main__":
    main()
