#!/usr/bin/env python3
"""Compila la sonda raw usando un subconjunto auditado del PS4 payload SDK."""
from __future__ import annotations

import hashlib
import argparse
import ipaddress
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ZIG = ROOT / "research" / "toolchains" / "zig-0.13.0" / "zig-windows-x86_64-0.13.0" / "zig.exe"
SDK = ROOT / "research" / "sources" / "ps4-payload-sdk" / "libPS4"
WORK = ROOT / "work" / "readonly-probe-build"
OUT_DIR = ROOT / "probe" / "build"
OUT_BIN = OUT_DIR / "goldhen_readonly_probe.bin"
OUT_ELF = WORK / "goldhen_readonly_probe.elf"
FLAGS = [
    "-target", "x86_64-freestanding-none", "-Os", "-std=c11",
    "-ffunction-sections", "-fdata-sections", "-fno-builtin",
    "-fno-stack-protector", "-nostartfiles", "-nostdlib", "-Wall", "-Wextra",
    "-masm=intel", "-march=btver2", "-mtune=btver2", "-m64", "-mabi=sysv",
    "-mcmodel=small", "-fpie", "-fPIC",
]


def run(args: list[str], cwd: Path) -> None:
    proc = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(f"Falló ({proc.returncode}): {' '.join(args)}\n{proc.stdout}\n{proc.stderr}")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-host", required=True,
                        help="IPv4 LAN del PC receptor; se incrusta en el BIN")
    parser.add_argument("--report-port", type=int, default=9090,
                        help="puerto TCP del receptor (predeterminado: 9090)")
    args = parser.parse_args()
    try:
        report_ip = str(ipaddress.IPv4Address(args.report_host))
    except ipaddress.AddressValueError as exc:
        parser.error(f"--report-host debe ser una IPv4: {exc}")
    if not 1 <= args.report_port <= 65535:
        parser.error("--report-port debe estar entre 1 y 65535")

    if not ZIG.is_file():
        raise SystemExit(f"No se encontró Zig 0.13.0: {ZIG}")
    if not SDK.is_dir():
        raise SystemExit(f"No se encontró el SDK fijado: {SDK}")

    # Solo copias de trabajo. El checkout fijado del SDK queda intacto.
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    copied = WORK / "libPS4"
    shutil.copytree(SDK, copied)

    kernel_c = copied / "source" / "kernel.c"
    kernel_text = kernel_c.read_text(encoding="utf-8")
    forbidden_stub = "SYSCALL(kexec, 11);"
    if kernel_text.count(forbidden_stub) != 1:
        raise SystemExit("No pude identificar exactamente el stub kexec del SDK; build cancelado")
    kernel_text = kernel_text.replace(forbidden_stub, "/* kexec excluido de esta sonda */")
    kill_stub = "SYSCALL(kill, 37);"
    if kernel_text.count(kill_stub) != 1:
        raise SystemExit("No pude identificar exactamente el stub kill del SDK; build cancelado")
    kernel_text = kernel_text.replace(kill_stub, "/* kill excluido de esta sonda */")
    kernel_c.write_text(kernel_text, encoding="utf-8")

    # Normalización sintáctica de Clang IAS en la copia temporal del SDK.
    syscall_h = copied / "include" / "syscall.h"
    syscall_h.write_text(syscall_h.read_text(encoding="utf-8").replace("movq rax,", "mov rax,"), encoding="utf-8")
    syscall_s = copied / "source" / "syscall.s"
    syscall_text = syscall_s.read_text(encoding="utf-8").replace("movq rax,", "mov rax,").replace("movq rdx,", "mov rdx,")
    generic_stub = ".globl syscall\nsyscall:\n\txor rax, rax\n\n"
    if generic_stub not in syscall_text:
        raise SystemExit("No se encontró el wrapper genérico del SDK para excluirlo")
    syscall_s.write_text(syscall_text.replace(generic_stub, "", 1), encoding="utf-8")
    crt0 = WORK / "crt0.s"
    crt0.write_text((copied / "crt0.s").read_text(encoding="utf-8").replace(
        ".text", '.section .text.start,"ax"', 1), encoding="utf-8")

    include = "-I" + str(copied / "include")
    sources = [
        copied / "source" / "kernel.c",
        copied / "source" / "network.c",
        copied / "source" / "syscall.s",
        ROOT / "probe" / "probe_syscalls.c",
        ROOT / "probe" / "goldhen_readonly_probe.c",
    ]
    objects: list[Path] = []
    for index, src in enumerate(sources):
        obj = WORK / f"obj_{index}_{src.stem}.o"
        run([str(ZIG), "cc", *FLAGS, include,
             f'-DPROBE_REPORT_IP="{report_ip}"',
             f"-DPROBE_REPORT_PORT={args.report_port}",
             "-c", str(src), "-o", str(obj)], ROOT)
        objects.append(obj)

    run([
        str(ZIG), "cc", *FLAGS,
        "-Wl,-T," + str(copied / "linker.x"),
        "-Wl,--build-id=none", "-Wl,--gc-sections",
        str(crt0), *map(str, objects), "-o", str(OUT_ELF),
    ], ROOT)
    run([str(ZIG), "objcopy", "-O", "binary", str(OUT_ELF), str(OUT_BIN)], ROOT)

    blob = OUT_BIN.read_bytes()
    if report_ip.encode("ascii") not in blob:
        raise SystemExit("El BIN raw no contiene la IP indicada para el receptor")
    print(f"raw_prefix={blob[:16].hex(' ')}")
    if not blob or blob[0] != 0xE9:
        raise SystemExit("El BIN no empieza con el salto rel32 esperado por el BinLoader")
    if b"kexec" in blob or b"jailbreak" in blob or bytes.fromhex("07 8f 1c c0") in blob:
        raise SystemExit("Auditoría fallida: se encontró kexec/jailbreak o ioctl SET del ventilador")
    if bytes.fromhex("08 8f 1c c0") not in blob:
        raise SystemExit("Auditoría fallida: no se encontró la constante ioctl GET")

    print(f"compiler=Zig 0.13.0 / Clang 18.1.6")
    print(f"report_endpoint={report_ip}:{args.report_port}")
    print(f"sdk=Scene-Collective/ps4-payload-sdk fd4f7299d1da5f5601c164a02b6d6d019ac8630a")
    print(f"source={ROOT / 'probe' / 'goldhen_readonly_probe.c'}")
    print(f"raw_bin={OUT_BIN}")
    print(f"bytes={len(blob)} sha256={sha256(OUT_BIN)}")
    print(f"elf_symbols={OUT_ELF} (inspección local con zig objdump -t)")
    print("audit=pass: raw E9 entry; no kexec/jailbreak text or SET ioctl; GET ioctl present")


if __name__ == "__main__":
    main()
