# Tooling de investigación

Fecha de corte: 2026-11-18. Todo se instaló o descargó dentro del proyecto.

| Herramienta | Versión/fijación | Fuente | Uso |
|---|---|---|---|
| Python | 3.12.10 del host | instalación ya disponible; no se modificó | Ejecutar análisis local reproducible |
| venv | `.venv` | módulo estándar de Python | Aislar dependencias |
| Capstone | 5.0.9 | PyPI (`https://pypi.org/project/capstone/`) | Desensamblar x86-64 desde offset 0 |
| Git | versión del host | ya disponible | Clonar fuentes fijando SHA de commit |
| Script propio | `tools/forensic.py` | proyecto | Hashes, inventario, strings, diffs, escaneo x86-64 y qwords; no ejecuta payloads |
| Zig | 0.13.0 | [ziglang.org](https://ziglang.org/download/) portable archive, SHA-256 `d859994725ef9402381e557c60bb57497215682e355204d754ee3df75ee3c158` | Intento de rebuild PS4 payload; empaqueta Clang 18.1.6 |
| OpenOrbis toolchain package | v0.5.4 | [OpenOrbis/PS4-Toolchain](https://github.com/OpenOrbis/PS4-Toolchain/releases/tag/v0.5.4), SHA-256 `3c7cd5bb593ca74fa1c13fd59f3938dc0fc07985167f7275063019e63abe4526` | Inspección de toolchain/SDK; el asset descargado no incluía compilador Windows nativo |
| Scripts de análisis | `tools/scan_goldhen.py`, `tools/fetch_goldhen_releases.py` | Proyecto | Escaneo estático de strings y descarga de assets oficiales pequeños de releases; manifiesto con URL/hash |
| Helper de rebuild | `tools/rebuild_known_fan.py` | Proyecto | Compila fuente fan en copias bajo `work/`; nunca ejecuta payloads |
| GoldHEN release assets | Releases 2.2–2.4b18; URLs y SHA en `research/goldhen_releases/manifest.json` | [GoldHEN releases](https://github.com/GoldHEN/GoldHEN/releases) | Buscar strings de ICC, rutas update y BinLoader. El scan negativo no demuestra ausencia funcional |
| WebRTE | Commit `557eea8141d6991d848366fd103dc635936285fd`, más submódulos fijados en checkout | [saudid0s/WebRTE](https://github.com/saudid0s/WebRTE) | Contrato de ioctl GET/SET en fuente PS4 y ejemplo de tabla de ventilador |

No se instalaron herramientas globales ni se descargaron PUPs, kernels o dumps. Releases y toolchains descargados se guardaron dentro de `research/`; assets de releases <200 MB. Las fuentes Git fijadas están en `sources/` y `research/sources/`; commits, aportes y confianza se enumeran en [README.md](README.md). Los BIN originales se copiaron a `work/originals/` para análisis y nunca se ejecutaron. El rebuild falló la identidad bit a bit; ver [PLAN.md](PLAN.md) y [PORTABILITY.md](PORTABILITY.md).
