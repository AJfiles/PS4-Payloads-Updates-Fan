# Fuentes y bitácora de investigación

Fecha de consulta/corte: 2026-11-18. Repositorios clonados con profundidad limitada; SHA completo fijado localmente. No se enviaron hashes, strings ni archivos del usuario a servicios externos. La búsqueda pública de procedencia usó únicamente hashes calculados localmente y nombres/strings ya extraídos de los binarios.

| Fuente | Commit | Qué aporta | Confianza |
|---|---|---|---|
| [ps4-fan-threshold](https://github.com/Scene-Collective/ps4-fan-threshold) | `b68a4a8256aa550b074226e00d1d6a7a1b0e8c2a` | Código C que abre `/dev/icc_fan`, llena el byte 5 del buffer y llama ioctl `0xC01C8F07`; origen/implementación de la familia 9.00 compatible por lógica y strings | Alta para mecanismo del código; no se afirma hash exacto de los BIN 9.00 |
| [ps4-disable-updates](https://github.com/Scene-Collective/ps4-disable-updates) | `6f4f7ab67752ad5fb97b2f27c84ba2810eff39c0` | Crea directorios señuelo `PS4UPDATE.PUP` y `.net.temp` bajo `/update` | Alta para comportamiento descrito en fuente |
| [ps4-enable-updates](https://github.com/Scene-Collective/ps4-enable-updates) | `6dc5f0ca939363cb61698b2145259b9c5982eee4` | Elimina los directorios señuelo; no reconstruye un estado previo arbitrario | Alta |
| [PS4-fan-control-payloads](https://github.com/toxxic407/PS4-fan-control-payloads) | `0c0bb794a42aed998de04bd599b541edbbec0700` | Binarios históricos por firmware; hash exacto confirma que los siete BIN Fan 5.05 del usuario coinciden con `5.05_bin_payloads/{50..80}.bin` | Alta para identidad de esos siete archivos |
| [PS4-fan-control](https://github.com/ethylamine/PS4-fan-control) | `5cf7641fd881ffd14db0680bcd5aba2af0e1ced3` | Código/familia de control de ventilador | Media; no equivale a prueba de identidad de los BIN del usuario |
| [ps4-payload-sdk](https://github.com/Scene-Collective/ps4-payload-sdk) | `fd4f7299d1da5f5601c164a02b6d6d019ac8630a` | SDK usado por ejemplos de payload | Alta para el commit consultado |
| [WebRTE](https://github.com/saudid0s/WebRTE) | `557eea8141d6991d848366fd103dc635936285fd` | Fuente PS4 de terceros que documenta SET/GET ICC de ventilador, buffer de 28 bytes, tablas por zona y `/dev/icc_fan`; no es especificación oficial y su evidencia no se extrapola a todos los FW/modelos | Media para su implementación declarada; no validado en nuestra consola |
| [ps4-payload-repo](https://github.com/Scene-Collective/ps4-payload-repo) | `7ef5bb927866c23bf1607abcb827832f316f29dd` | Índice/repositorio de payloads; commit clonado contiene principalmente submódulos | Baja como evidencia funcional |
| [Afterglow web host](https://github.com/well0nez/afterglow-web) | `587c00a564c4765b78ab413e400a392efdd9a780` | Cadena WebKit + kernel para FW 12.00–14.02, patchsets, selección ps4-hen/GoldHEN y loader | Alta para el comportamiento declarado/código de ese commit; no es validación de consola propia |
| [GoldHEN upstream](https://github.com/GoldHEN/GoldHEN) | consultado en línea 2026-11-18; no se fijó un commit adicional | Releases y soporte oficial; upstream publicado no documenta 14.02 | Alta para el estado del repositorio consultado |
| [Exploit chart](https://consolemods.org/wiki/PS4:Exploit_Chart) | página viva consultada 2026-11-18 | Lista discreta de exploits por firmware y caveats de calidad | Media; fuente comunitaria secundaria |
| [Issue GoldHEN #422](https://github.com/GoldHEN/GoldHEN/issues/422) | issue abierto el 2026-11-07 | Evidencia de solicitud de soporte 14.02 en upstream, no de soporte ya integrado | Alta para estado del issue |

## Hallazgos nuevos de portabilidad

El SDK contiene una ruta `jailbreak()` condicional: si UID es 0 y no hay sandbox, retorna; si no, usa `kexec` y offsets específicos. No se encontró evidencia documental de que todos los BinLoader de GoldHEN entreguen esas credenciales. La tabla ICC de WebRTE identifica `0xC01C8F07` como SET y `0xC01C8F08` como GET de 28 bytes; el payload histórico solo inicializa 10 bytes, por lo que no se debe imitar hasta confirmar el ABI completo por versión/modelo. Los detalles están en [PORTABILITY.md](PORTABILITY.md).

El usuario canceló la adquisición de kernels, dumps y PUP: no aplica el checkpoint de PUP. Ver [KERNELS.md](KERNELS.md). Toolchains y escaneos de releases se registran en [TOOLING.md](TOOLING.md).

## Hallazgo de procedencia

Los siete binarios Fan 5.05 son byte por byte idénticos a los publicados en `PS4-fan-control-payloads`. El código de `ps4-fan-threshold` explica la ruta ICC usada por los 9.00, pero el hash exacto de esos ocho BIN no quedó vinculado a una fuente pública clonada. Los BIN de bloqueo/activación son coherentes con los repositorios Scene-Collective; sin coincidencia SHA demostrada, la atribución exacta de cada archivo queda como probable, no confirmada.

## Afterglow y GoldHEN 14.02

Afterglow es el proyecto `well0nez/afterglow-web`; su README atribuye la cadena WebKit + kernel al host y enumera 14.02 entre sus firmwares. El mismo README dice que incluye `goldhen.bin` con permiso de SiSTRo y distribuye patchsets de kernel por versión. En `afterglow.js` aparece el mensaje de versión **GoldHEN v2.4b18.12 loaded**; el blob (298,776 bytes, SHA-256 `c5480587d99efc2e3cc132352d9b7cf052dd3068280f1686e7fbb37d57e9ba8b`) no coincide con el asset upstream v2.4b18 (260,160 bytes, SHA-256 `eb9fee5e9e3618c0a144a6fc6b8fc1ec7e89cf06483ad64ae7c1085efc9525a3`). Clasificación: **build comunitario incluido por Afterglow, no upstream release**; el repositorio no declara que sea un fork formal y no se demostró su linaje exacto. El host aplica patchsets antes de cargar GoldHEN e incluye código que inyecta el servicio BinLoader en el puerto 9090. Además, un helper distinto reconoce payload raw por byte inicial `E9`, lo mapea e inicia en un thread. El código confirma el destino `9090`, pero no basta para demostrar que la inyección conserve el mismo ABI o contexto de ejecución que un release upstream. El issue #422 de upstream solicita 14.02 y no constituye soporte integrado.

## Notas de adquisición

No hay dumps de kernel adquiridos en esta fase. Las filas de offsets publicadas de Scene-Collective y el dumper 14.02 son pistas de offsets/herramientas, no sustituyen kernels comprobados. No se descargó ningún PUP. Ver [KERNELS.md](KERNELS.md) y [PLAN.md](PLAN.md).

## Referencias adicionales fijadas para update/fan y ELF loader

| Fuente | Commit | Artefactos adquiridos | Aporte y confianza |
|---|---|---|---|
| [WPA-Libertario/PS4-Payloads-4.50-13.52](https://github.com/WPA-Libertario/PS4-Payloads-4.50-13.52/tree/a5e483abc5011dff2d72b1fd4bfe5dc5bdf57f74) | `a5e483abc5011dff2d72b1fd4bfe5dc5bdf57f74` | Tres BIN update solicitados, carpeta `fan-thresholds` completa, dos artefactos elfldr y README | Evidencia primaria de artefactos y rangos declarados por ese repo; no valida cada versión/modelo. Hashes y límites en [REFERENCE_REPO_FINDINGS.md](../analysis/REFERENCE_REPO_FINDINGS.md) y [REFERENCE_PAYLOADS.md](../analysis/REFERENCE_PAYLOADS.md). |
| [ps4-payload-dev/elfldr](https://github.com/ps4-payload-dev/elfldr/tree/a4817404f5cb2d5c177b05cd5e4548b74e6c2725) | `a4817404f5cb2d5c177b05cd5e4548b74e6c2725` | README, bootstrap, ELF loader, socket server y archivos de soporte necesarios | Fuente upstream del loader ELF. Confianza alta para el código del commit; no extrapolar a artefactos de otros commits ni a 14.02. Revisión en [DUAL_BUILD_PROPOSAL.md](../analysis/DUAL_BUILD_PROPOSAL.md). |

La revisión de permisos usa las páginas oficiales FreeBSD [`rmdir(2)`](https://man.freebsd.org/cgi/man.cgi?query=rmdir&sektion=2&manpath=FreeBSD+14.0-RELEASE) y [`mkdir(2)`](https://man.freebsd.org/cgi/man.cgi?query=mkdir&sektion=2&manpath=FreeBSD+14.0-RELEASE): `rmdir` exige directorio vacío y permisos de escritura sobre el padre; `mkdir` restringe el modo solicitado con `umask`.
