PAQUETE V1 (UNIVERSAL) — BLOQUEO MÍNIMO
Payloads de ventilador (8 umbrales):
fan_threshold_XX_universal.bin: Fija umbral térmico a XX °C
fan_default_universal.bin: Restaura umbral stock (79 °C)
Payloads de updates (2):
disable_updates_universal.bin: Crea directorios señuelo en /update
Bloquea descarga del PUP de sistema. PSN sigue funcionando.
enable_updates_universal.bin: Elimina directorios señuelo
Permite actualizaciones de sistema. Usar solo temporalmente.
Uso diario:
disable_updates_universal.bin (una vez, persiste)
fan_threshold_60_universal.bin (una vez, persiste)
Para actualizar sistema:
enable_updates_universal.bin
Actualizar
disable_updates_universal.bin inmediatamente
Firma: Todos los payloads incluyen "— AJ" en notificaciones.
