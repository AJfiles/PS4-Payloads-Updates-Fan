# Payloads userland para GoldHEN (PS4)

Este proyecto genera payloads raw para cargar por BinLoader de GoldHEN. Usa una sola base de código por función y no depende de offsets de kernel. Son **universales por diseño, condicionados a interfaces verificadas**, no una promesa de compatibilidad total. Cada payload comprueba UID 0 y sandbox inactivo; aborta si no tiene ese contexto. Fan depende además de `/dev/icc_fan`; updates actúa únicamente sobre dos rutas estándar bajo `/update`.

## Binarios

- `fan_threshold_50/55/60/65/70/75/80_universal.bin`: aplica el umbral solicitado mediante GET de la tabla ICC de 28 bytes, modifica solo byte 5, hace SET y verifica por GET.
- `fan_default_universal.bin`: aplica 79; no restaura una copia previa.
- `disable_updates_universal.bin`: crea directorios señuelo en `/update/PS4UPDATE.PUP` y `/update/PS4UPDATE.PUP.net.temp`. Si encuentra ficheros regulares, los elimina antes de crear los señuelos; cualquier PUP ahí se pierde. Sobrevive al reinicio.
- `enable_updates_universal.bin`: solo hace `rmdir` de esas dos rutas canónicas cuando cada una es un directorio vacío. El modo y propietario son irrelevantes; si hay contenido o no puede comprobar que está vacío, aborta. Nunca borra recursivamente ni elimina archivos.

**Alcance:** el payload bloquea la descarga del PUP de actualización del sistema mediante esas dos rutas. No bloquea parches de juegos ni actualizaciones de aplicaciones, que usan otras rutas y mecanismos.

Todos notifican el resultado y envían log TCP al PC configurado al compilar. Los mensajes se muestran como notificación GoldHEN/PS4. El límite del campo de mensaje del SDK es 1024 bytes.

## Estado de evidencia

**VERIFICADO:** PS4 Pro 9.00 + GoldHEN 2.4b18.10, contexto BinLoader root sin sandbox, nodo ICC y GET; originales fan60/default; todos los umbrales universales y default medidos. La sonda C, tomada tras el reinicio reportado y antes de los smoke tests posteriores, leyó `0x3C` dos veces, confirmando que ese ajuste sobrevivió al reinicio y a recargar GoldHEN. El default aplica 79, el valor stock observado; vuelve a ese valor, no restaura una copia previa. El signo `°` se vio correctamente en la notificación de E2.

**VERIFICADO en esta consola:** los umbrales 50, 55, 60, 65, 70, 75, 80 y default 79 pasaron medidas individuales; cada captura cambió solo el byte 5 y la sonda leyó el mismo valor. 80 mostró el aviso de que supera el stock observado. El estado final quedó en 79. Las capturas están en [analysis](analysis/FAN_SMOKE_TESTS.md).

**ALTA CONFIANZA TÉCNICA, NO GARANTIZADO:** otras PS4 con GoldHEN que expongan root sin sandbox, `/dev/icc_fan`, los ioctls `0xC01C8F07/08` y las rutas `/update` estándar. Los originales de updates de 5.05 a 11.00 usaron las mismas rutas; los originales fan de 5.05 y 9.00 usaron `/dev/icc_fan`, pero el payload nuevo de fan solo está verificado en 9.00. Todo BIN nuevo comprueba sus precondiciones en runtime y aborta sin operar si no las cumple.

**DESCONOCIDO/EXPERIMENTAL:** builds comunitarios, 14.02/Afterglow, GoldHEN antiguo, otros loaders y modelos no probados. No hay offsets de kernel; la dependencia real son las interfaces y permisos disponibles en runtime. La versión mínima compatible de GoldHEN se desconoce.

## Seguridad y límites

Los originales del fan y los cuatro BIN del repo de referencia (60/70/80/85) pasan 10 bytes a un ioctl `_IOWR` de 28 bytes; la llamada puede leer 18 bytes fuera del buffer y copiar 18 bytes de vuelta más allá de él. Los BIN nuevos usan GET-modify-SET con buffer de 64 bytes y solo cambian el byte 5; ofrecen 50–80 y default 79. El valor 80 supera el stock observado de 79: no es refrigeración extra. El umbral ICC es un objetivo del ventilador, no un techo duro de temperatura ni una protección térmica. Ningún BIN nuevo contiene `kexec`, syscall 11 ni offsets de kernel.

El bloqueo de updates cambia el sistema de archivos y persiste al apagar. Solo bloquea el PUP de actualización del sistema; no bloquea parches de juegos ni actualizaciones de aplicaciones. `disable` elimina primero cualquier fichero regular que encuentre en las dos rutas, así que un PUP descargado allí se pierde, y luego crea los directorios señuelo. `enable` retira solo directorios vacíos en las rutas exactas mediante `rmdir`; modo y propietario no participan en la decisión. Si encuentra ficheros, contenido inesperado o no puede confirmar que estén vacíos, aborta. No se cambia DNS. El roundtrip de los BIN reconstruidos está en [analysis/probe_F_recheck.txt](analysis/probe_F_recheck.txt); el roundtrip histórico anterior se conserva en [analysis/probe_F.txt](analysis/probe_F.txt).

El desensamblado de los payloads originales muestra que `disable` pasa `0x309` a `mkdir`, equivalente a octal `01411`; eso no explica los modos observados `0777` y `0555`, y `umask` solo puede quitar bits. La causa queda **NO RESUELTA**: pudo haber un `chmod` posterior, normalización del filesystem o creación por otro payload. El modo no cambia el bloqueo: lo determinante es que la ruta sea un directorio en lugar de un fichero PUP. La hipótesis de que `0555` impide `rmdir` está descartada; FreeBSD verifica que el directorio esté vacío y la escritura/permisos del padre, no el modo del hijo ([manual `rmdir(2)`](https://man.freebsd.org/cgi/man.cgi?query=rmdir&sektion=2&manpath=FreeBSD+14.0-RELEASE)).

Consulta [docs/INSTALL.md](docs/INSTALL.md) para la carga y [docs/TESTING.md](docs/TESTING.md) para las medidas secuenciales. Los resultados de hardware están en `analysis/probe_*.txt`; los hashes están en `payloads/build/SHA256SUMS.txt`.

La sonda de compatibilidad y su plantilla están en [docs/PROBE.md](docs/PROBE.md) y [docs/PROBE_REPORT_TEMPLATE.md](docs/PROBE_REPORT_TEMPLATE.md). Recompila la sonda con la IPv4 de tu propio PC antes de cargarla. Para informar un fallo o confirmar otro firmware, usa la plantilla de reporte.

La capa ELF/`elfldr` y NP Environment quedan aparcadas como proyectos separados; ver [propuesta de builds duales](analysis/DUAL_BUILD_PROPOSAL.md) y [nota NP Environment](research/NP_ENVIRONMENT.md). El upstream fijado de `elfldr` declara hasta 14.00 y requiere `remote_lua_loader`; no es drop-in para Afterglow y aquí no se promete soporte para 14.02.
