# Experimento ICC: cuatro medidas

Cada reporte de la sonda debe contener dos GET. Guarda y pega los cuatro reportes completos; no edites sus hexdumps. Usa la misma PS4, firmware y build de GoldHEN. No reinicies entre A y B ni entre C y D.

## Secuencia

- **A — Línea base en frío:** recién cargado GoldHEN, sin tocar un control de fan; carga sonda y guarda sus dos GET.
- **B — Fan 60:** carga el BIN fan 60 conocido como bueno de 9.00; a continuación carga sonda y guarda sus dos GET.
- **C — Persistencia:** reinicia la consola, vuelve a cargar GoldHEN sin aplicar otro fan; carga sonda y guarda sus dos GET.
- **D — Valor 79:** carga el BIN `fanDefault` de 9.00; después carga sonda y guarda sus dos GET.

La sonda solo consulta. Los cambios entre capturas proceden de los BIN fan indicados y del reinicio.

## Datos de la sesión

- Fecha/hora y orden de ejecución:
- Modelo/revisión PS4:
- Firmware/build:
- GoldHEN:
- IP/puerto receptor:
- Fan 60 exacto:
- BIN default 79 exacto:
- ¿Hubo otro reinicio, payload o cambio entre medidas?:

## Capturas

Completa este bloque para A, B, C y D, incluyendo los 28 bytes de ambas lecturas:

### Medida A / B / C / D

- Reporte completo:
- GET 1: retorno / errno:
- GET 1 bytes 0–27: `__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __`
- GET 2: retorno / errno:
- GET 2 bytes 0–27: `__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __`
- GET 1 == GET 2:
- Estado/temperatura/ruido percibido (si se anotó):

## Comparaciones

Calcula byte a byte del offset `0x00` al `0x1B`, y dwords little-endian para offsets `0x00`, `0x04`, `0x08`, `0x0C`, `0x10`, `0x14`, `0x18`. Conserva explícitamente los offsets iguales.

| Offset | A | B | A→B XOR | B | C | B→C XOR | C | D | C→D XOR |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0x00 | — | — | — | — | — | — | — | — | — |
| 0x01 | — | — | — | — | — | — | — | — | — |
| 0x02 | — | — | — | — | — | — | — | — | — |
| 0x03 | — | — | — | — | — | — | — | — | — |
| 0x04 | — | — | — | — | — | — | — | — | — |
| 0x05 | — | — | — | — | — | — | — | — | — |
| 0x06–0x1B | — | — | — | — | — | — | — | — | — |

| Dword LE (offset) | A | B | A→B | C | B→C | D | C→D |
|---|---:|---:|---|---:|---|---:|---|
| 0x00 (0–3) | — | — | — | — | — | — | — |
| 0x04 (4–7) | — | — | — | — | — | — | — |
| 0x08 (8–11) | — | — | — | — | — | — | — |
| 0x0C (12–15) | — | — | — | — | — | — | — |
| 0x10 (16–19) | — | — | — | — | — | — | — |
| 0x14 (20–23) | — | — | — | — | — | — | — |
| 0x18 (24–27) | — | — | — | — | — | — | — |

## Qué permite concluir

- **A→B:** identifica bytes que cambian tras fan 60 y evalúa si GET expone estado relacionado con SET; no asigna significado semántico a campos desconocidos por sí solo.
- **B→C:** si el patrón de B sigue presente después del reinicio y recarga de GoldHEN, eso es evidencia de persistencia para esta consola/configuración; si cambia, no persistió igual.
- **C→D:** mide el efecto del BIN que aplica 79. No es una prueba de reversibilidad exacta ni de restauración de fábrica: `default` aplica el valor 79 y no restaura el snapshot A.

El valor 80 supera el valor stock indicado de 79. No uses esta observación para generalizar a otros modelos o firmwares.
